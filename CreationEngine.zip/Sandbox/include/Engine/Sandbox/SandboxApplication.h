/*
#pragma once

#include <Engine/Core/Application.h>

namespace Engine::Sandbox
{
	class SandboxApplication : public Engine::Core::Application
	{
	public:
		SandboxApplication();
	};
}
*/