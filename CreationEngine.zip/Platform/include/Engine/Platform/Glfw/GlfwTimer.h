#pragma once

namespace Engine::Platform::Glfw
{
    double GlfwGetTimeSeconds();
}