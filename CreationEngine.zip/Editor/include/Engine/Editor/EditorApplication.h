#pragma once

#include <Engine/Core/Application.h>

namespace Engine::Editor
{
	class EditorApplication : public Engine::Core::Application
	{
	public:
		EditorApplication();
	};
}